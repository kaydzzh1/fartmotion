import React, { useState } from "react";
import {
  SafeAreaView, View, Text, Pressable, ScrollView, StyleSheet,
  StatusBar, Alert, Image, TextInput
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import * as DocumentPicker from "expo-document-picker";

type Layer = {
  id: number;
  name: string;
  kind: "Video" | "Image" | "Text" | "Audio";
  color: string;
  uri?: string;
};

const TEAL = "#56F0D0";
const BG = "#0B0D11";
const PANEL = "#151920";
const MUTED = "#89919F";

export default function App() {
  const [layers, setLayers] = useState<Layer[]>([
    { id: 1, name: "Main clip", kind: "Video", color: "#20B8A6" },
    { id: 2, name: "Text layer", kind: "Text", color: "#8A6CFF" }
  ]);
  const [selected, setSelected] = useState(1);
  const [projectName, setProjectName] = useState("My first edit");
  const [playhead, setPlayhead] = useState(35);
  const [playing, setPlaying] = useState(false);

  const selectedLayer = layers.find(layer => layer.id === selected);

  const addImage = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert("Photo access needed", "Allow photo access in Settings to import media.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images", "videos"],
      allowsEditing: false,
      quality: 1
    });
    if (result.canceled || !result.assets?.[0]) return;
    const asset = result.assets[0];
    const isVideo = asset.type === "video";
    const id = Date.now();
    setLayers(prev => [...prev, {
      id,
      name: asset.fileName || (isVideo ? "Imported video" : "Imported image"),
      kind: isVideo ? "Video" : "Image",
      color: isVideo ? "#20B8A6" : "#E6A34D",
      uri: asset.uri
    }]);
    setSelected(id);
  };

  const addAudio = async () => {
    const result = await DocumentPicker.getDocumentAsync({
      type: ["audio/*"],
      copyToCacheDirectory: true
    });
    if (result.canceled || !result.assets?.[0]) return;
    const asset = result.assets[0];
    const id = Date.now();
    setLayers(prev => [...prev, {
      id, name: asset.name || "Audio track", kind: "Audio",
      color: "#E6A34D", uri: asset.uri
    }]);
    setSelected(id);
    Alert.alert("Audio added", "The audio file is listed in your project. Audio mixing/export will be added in a later version.");
  };

  const addText = () => {
    const id = Date.now();
    setLayers(prev => [...prev, {
      id, name: "New text", kind: "Text", color: "#8A6CFF"
    }]);
    setSelected(id);
  };

  const deleteSelected = () => {
    if (!selectedLayer) return;
    setLayers(prev => prev.filter(layer => layer.id !== selected));
    setSelected(0);
  };

  const exportProject = () => {
    Alert.alert(
      "Export not enabled yet",
      "This starter build can organize imported media and layers, but it does not render a finished MP4 yet. The export engine needs to be implemented before this button can create a video."
    );
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor={BG} />
      <View style={styles.header}>
        <View>
          <Text style={styles.brand}>FART<Text style={{ color: TEAL }}>MOTION</Text></Text>
          <Text style={styles.subhead}>MOBILE VIDEO STUDIO</Text>
        </View>
        <Pressable style={styles.exportButton} onPress={exportProject}>
          <Text style={styles.exportText}>Export ↗</Text>
        </Pressable>
      </View>

      <View style={styles.projectRow}>
        <View style={{ flex: 1 }}>
          <Text style={styles.smallLabel}>PROJECT</Text>
          <TextInput
            value={projectName}
            onChangeText={setProjectName}
            style={styles.projectInput}
            placeholder="Project name"
            placeholderTextColor={MUTED}
          />
        </View>
        <View style={styles.fpsPill}><Text style={styles.fpsText}>1080p · 30 FPS</Text></View>
      </View>

      <View style={styles.previewWrap}>
        <View style={styles.previewTop}>
          <Text style={styles.smallLabel}>PREVIEW</Text>
          <Text style={styles.timecode}>00:00:{String(Math.round(playhead * 0.3)).padStart(2, "0")}</Text>
        </View>
        <View style={styles.preview}>
          {selectedLayer?.uri && selectedLayer.kind === "Image" ? (
            <Image source={{ uri: selectedLayer.uri }} style={styles.previewImage} resizeMode="contain" />
          ) : (
            <View style={styles.previewPlaceholder}>
              <View style={styles.previewMark}><Text style={styles.playGlyph}>▶</Text></View>
              <Text style={styles.previewTitle}>{selectedLayer?.kind === "Text" ? selectedLayer.name : "Your edit starts here"}</Text>
              <Text style={styles.previewHint}>Import media to build your composition</Text>
            </View>
          )}
        </View>
        <View style={styles.transport}>
          <Pressable onPress={() => setPlayhead(0)}><Text style={styles.transportIcon}>|◀</Text></Pressable>
          <Pressable style={styles.playButton} onPress={() => setPlaying(!playing)}>
            <Text style={styles.playButtonText}>{playing ? "Ⅱ" : "▶"}</Text>
          </Pressable>
          <Pressable onPress={() => setPlayhead(Math.min(100, playhead + 10))}><Text style={styles.transportIcon}>▶|</Text></Pressable>
          <View style={{ flex: 1 }} />
          <Text style={styles.transportLabel}>{playing ? "PLAYING" : "READY"}</Text>
        </View>
      </View>

      <View style={styles.timelineHead}>
        <Text style={styles.sectionTitle}>Timeline</Text>
        <Text style={styles.layerCount}>{layers.length} layers</Text>
      </View>
      <View style={styles.ruler}>
        <Text style={styles.rulerText}>00:00</Text>
        <Text style={styles.rulerText}>00:02</Text>
        <Text style={styles.rulerText}>00:04</Text>
        <Text style={styles.rulerText}>00:06</Text>
        <Text style={styles.rulerText}>00:08</Text>
      </View>
      <ScrollView style={styles.timeline} contentContainerStyle={{ paddingBottom: 8 }}>
        {layers.map((layer, index) => (
          <Pressable
            key={layer.id}
            onPress={() => setSelected(layer.id)}
            style={[styles.layerRow, selected === layer.id && styles.layerRowSelected]}
          >
            <View style={[styles.layerType, { backgroundColor: layer.color + "22" }]}>
              <Text style={[styles.layerTypeText, { color: layer.color }]}>{layer.kind === "Video" ? "▶" : layer.kind === "Image" ? "▧" : layer.kind === "Audio" ? "♫" : "T"}</Text>
            </View>
            <View style={styles.layerNameBox}>
              <Text numberOfLines={1} style={styles.layerName}>{layer.name}</Text>
              <View style={[styles.clip, { backgroundColor: layer.color + "35", borderColor: layer.color }]}>
                <Text numberOfLines={1} style={[styles.clipText, { color: layer.color }]}>{layer.name}</Text>
              </View>
            </View>
          </Pressable>
        ))}
        {layers.length === 0 && <Text style={styles.emptyText}>No layers yet. Add media below.</Text>}
      </ScrollView>
      <View style={[styles.playheadLine, { left: `${playhead}%` }]} pointerEvents="none" />

      <View style={styles.scrubber}>
        <Text style={styles.smallLabel}>PLAYHEAD</Text>
        <View style={{ flex: 1 }}>
          <View style={styles.sliderTrack}>
            <View style={[styles.sliderFill, { width: `${playhead}%` }]} />
            <View style={[styles.sliderKnob, { left: `${playhead}%` }]} />
          </View>
        </View>
        <Text style={styles.scrubberTime}>00:{String(Math.round(playhead * 0.3)).padStart(2, "0")}</Text>
      </View>
      <View style={styles.toolDock}>
        <Tool label="Media" glyph="＋" onPress={addImage} />
        <Tool label="Text" glyph="T" onPress={addText} />
        <Tool label="Audio" glyph="♫" onPress={addAudio} />
        <Tool label="Effects" glyph="✧" onPress={() => Alert.alert("Effects", "Color, blur, glow, and keyframed effects are planned for a later version.")} />
        <Tool label="Delete" glyph="⌫" onPress={deleteSelected} />
      </View>
      <Text style={styles.footer}>FARTMOTION · ORIGINAL PROJECTS · NO WATERMARK</Text>
    </SafeAreaView>
  );
}

function Tool({ label, glyph, onPress }: { label: string; glyph: string; onPress: () => void }) {
  return (
    <Pressable style={styles.tool} onPress={onPress}>
      <View style={styles.toolIcon}><Text style={styles.toolGlyph}>{glyph}</Text></View>
      <Text style={styles.toolLabel}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: BG, paddingHorizontal: 14 },
  header: { paddingTop: 8, paddingBottom: 12, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  brand: { color: "#F4F7FA", fontSize: 23, fontWeight: "900", letterSpacing: 1.2 },
  subhead: { color: MUTED, fontSize: 9, letterSpacing: 2, marginTop: 2 },
  exportButton: { backgroundColor: TEAL, paddingHorizontal: 16, paddingVertical: 10, borderRadius: 12 },
  exportText: { color: "#07110F", fontWeight: "800", fontSize: 13 },
  projectRow: { flexDirection: "row", alignItems: "center", marginBottom: 12, gap: 10 },
  smallLabel: { color: MUTED, fontSize: 9, fontWeight: "800", letterSpacing: 1.5 },
  projectInput: { color: "#F4F7FA", fontWeight: "700", fontSize: 16, paddingVertical: 3 },
  fpsPill: { backgroundColor: PANEL, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 8 },
  fpsText: { color: "#B9C2CF", fontSize: 10, fontWeight: "700" },
  previewWrap: { backgroundColor: PANEL, borderRadius: 16, padding: 10, borderWidth: 1, borderColor: "#242A34" },
  previewTop: { flexDirection: "row", justifyContent: "space-between", paddingBottom: 8 },
  timecode: { color: TEAL, fontSize: 11, fontVariant: ["tabular-nums"] },
  preview: { height: 185, backgroundColor: "#080A0E", borderRadius: 10, overflow: "hidden", alignItems: "center", justifyContent: "center" },
  previewImage: { width: "100%", height: "100%" },
  previewPlaceholder: { alignItems: "center" },
  previewMark: { width: 46, height: 46, borderRadius: 16, borderWidth: 1, borderColor: TEAL, alignItems: "center", justifyContent: "center", marginBottom: 12, backgroundColor: "#56F0D011" },
  playGlyph: { color: TEAL, fontSize: 17, marginLeft: 3 },
  previewTitle: { color: "#F4F7FA", fontSize: 15, fontWeight: "800" },
  previewHint: { color: MUTED, fontSize: 10, marginTop: 5 },
  transport: { flexDirection: "row", alignItems: "center", gap: 20, paddingTop: 10, paddingHorizontal: 6 },
  transportIcon: { color: "#C5CCD6", fontSize: 16 },
  playButton: { width: 34, height: 34, borderRadius: 12, backgroundColor: TEAL, alignItems: "center", justifyContent: "center" },
  playButtonText: { color: "#07110F", fontWeight: "900", fontSize: 15 },
  transportLabel: { color: MUTED, fontSize: 9, letterSpacing: 1.3, fontWeight: "800" },
  timelineHead: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 16, marginBottom: 8 },
  sectionTitle: { color: "#F4F7FA", fontSize: 16, fontWeight: "800" },
  layerCount: { color: MUTED, fontSize: 11 },
  ruler: { flexDirection: "row", justifyContent: "space-between", paddingLeft: 62, paddingRight: 4, paddingBottom: 7, borderBottomWidth: 1, borderColor: "#252B35" },
  rulerText: { color: "#737D8D", fontSize: 9, fontVariant: ["tabular-nums"] },
  timeline: { flexGrow: 0, maxHeight: 145, backgroundColor: "#101319", borderRadius: 10 },
  layerRow: { minHeight: 54, flexDirection: "row", alignItems: "center", paddingHorizontal: 8, borderBottomWidth: 1, borderBottomColor: "#222832" },
  layerRowSelected: { backgroundColor: "#56F0D00C" },
  layerType: { width: 30, height: 30, borderRadius: 8, alignItems: "center", justifyContent: "center", marginRight: 8 },
  layerTypeText: { fontSize: 15, fontWeight: "900" },
  layerNameBox: { flex: 1, gap: 4 },
  layerName: { color: "#E8ECF2", fontSize: 10, fontWeight: "700" },
  clip: { height: 20, borderRadius: 5, borderWidth: 1, paddingHorizontal: 6, justifyContent: "center", width: "72%" },
  clipText: { fontSize: 9, fontWeight: "700" },
  emptyText: { color: MUTED, textAlign: "center", padding: 18, fontSize: 12 },
  playheadLine: { position: "absolute", top: 0, width: 1, height: 1, backgroundColor: TEAL },
  scrubber: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 14 },
  sliderTrack: { height: 4, backgroundColor: "#2B323D", borderRadius: 3, justifyContent: "center" },
  sliderFill: { height: 4, backgroundColor: TEAL, borderRadius: 3 },
  sliderKnob: { position: "absolute", width: 12, height: 12, borderRadius: 6, backgroundColor: TEAL, marginLeft: -6, borderWidth: 2, borderColor: "#D9FFF7" },
  scrubberTime: { color: TEAL, fontSize: 10, width: 38, textAlign: "right", fontVariant: ["tabular-nums"] },
  toolDock: { flexDirection: "row", justifyContent: "space-between", backgroundColor: PANEL, borderRadius: 15, paddingVertical: 10, paddingHorizontal: 6, borderWidth: 1, borderColor: "#242A34" },
  tool: { alignItems: "center", flex: 1, gap: 5 },
  toolIcon: { width: 36, height: 36, borderRadius: 11, backgroundColor: "#222833", alignItems: "center", justifyContent: "center" },
  toolGlyph: { color: TEAL, fontSize: 19, fontWeight: "800" },
  toolLabel: { color: "#B8C1CE", fontSize: 9, fontWeight: "700" },
  footer: { color: "#626B79", textAlign: "center", fontSize: 8, letterSpacing: 1.4, paddingTop: 12, paddingBottom: 5 }
});
