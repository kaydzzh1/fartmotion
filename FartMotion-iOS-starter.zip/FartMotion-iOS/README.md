# FartMotion iOS starter

An original Expo / React Native starter interface for FartMotion. It is not an Alight Motion copy and does not modify Alight Motion. Projects created in a future full version can be exported without a FartMotion watermark.

## Included
- Dark mobile editing workspace
- Project name field
- Layer list and selection
- Import images/videos from the photo library
- Add text layer placeholders
- Add audio files to the layer list
- Basic playhead and transport UI
- Export placeholder that clearly explains MP4 rendering is not implemented yet

## Not included yet
- Actual timeline playback/compositing
- Keyframe animation engine
- Effects processing
- MP4 rendering/export
- Project persistence and undo/redo

## Build an iOS IPA with EAS Build

1. Install Node.js and the EAS CLI on a computer or compatible cloud development environment:
   `npm install -g eas-cli`
2. Install dependencies in this folder:
   `npm install`
3. Log in:
   `eas login`
4. Configure:
   `eas build:configure`
5. Build for iOS:
   `eas build --platform ios --profile preview`

EAS will guide you through Apple signing credentials. Installing on a physical iPhone requires valid signing and a supported distribution method. A free Apple account may not be sufficient for every distribution option. Check current Expo and Apple requirements before starting.

## iPhone-only note
This source ZIP is not itself an installable IPA. You can store it in Files, but generating an IPA requires a cloud build service and signing setup. Expo Go can preview many Expo projects, but it does not turn this project into a standalone IPA.
